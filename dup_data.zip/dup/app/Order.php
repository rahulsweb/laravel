<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
    protected $table = 'orders';
    protected $fillable = ['order_code', 'user_id', 'billing_id', 'shipping_id', 'coupon_id'];
    // user order relation
    public function users()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    //order payment relation
    public function orderPayment()
    {
        return $this->hasMany(OrderPaymentDetail::class, 'order_id');
    }

    //order cart relation
    public function order_carts()
    {
        return $this->belongsToMany(Product::class, 'order_cart_details')->withPivot('qty', 'total', 'images', 'created_at', 'total_cart', 'total_qty', 'category_name');
    }

    //log of each order relations
    public function log_order()
    {
        return $this->hasMany(LogOrder::class);
    }
    public function shipping_address()
    {
        return $this->belongsTo(Address::class, 'shipping_id');
    }
    public function billing_address()
    {
        return $this->belongsTo(Address::class, 'billing_id');
    }

    public function coupons()
    {
        return $this->belongsTo(Coupon::class, 'coupon_id');
    }

    //scope

    public function scopeGetOrder($query)
    {
        return $query->where('user_id', auth()->user()->id)->with('users', 'orderPayment', 'order_carts', 'log_order')->get();
    }

    public function scopeSearch($query, $keyword)
    {

        return $query->whereHas('users', function ($query) use ($keyword) {
            $query->where('first_name', 'LIKE', "%$keyword%");

            $query->orwhere('last_name', 'LIKE', "%$keyword%");

            $query->orwhere('email', 'LIKE', "%$keyword%");
        })->orwhereHas('log_order', function ($query) use ($keyword) {
            $query->where('status', 'LIKE', "%$keyword%");

        })->orwhere('order_code', 'LIKE', "%$keyword%")->with('users', 'orderPayment', 'order_carts', 'log_order');
    }
    public function scopeSearchEmail($query, $keyword)
    {

        return $query->whereHas('users', function ($query) use ($keyword) {
            whereHas('users', function ($query) use ($keyword) {
                $query->where('email', 'LIKE', "%$keyword%");
            })->orwhere('order_code', 'LIKE', "%$keyword%")->with('users');

        });

    }

    public function scopeOrderById($query)
    {

        return $query->WhereNotNull('coupon_id')->with('coupons', 'users')->orderBy('id', 'DESC');

    }
    public function scopeSearchByCoupons($query, $keyword)
    {

        return $query->whereHas('users', function ($query) use ($keyword) {

            $query->where('first_name', 'LIKE', "%$keyword%");

            $query->orwhere('email', 'LIKE', "%$keyword%");

        })->orwhereHas('coupons', function ($query) use ($keyword) {

            $query->where('code', 'LIKE', "%$keyword%");
            $query->orwhere('type', 'LIKE', "%$keyword%");
            $query->orwhere('title', 'LIKE', "%$keyword%");

        })->WhereNotNull('coupon_id')->with('coupons', 'users')->orderBy('id', 'DESC');

    }

}
