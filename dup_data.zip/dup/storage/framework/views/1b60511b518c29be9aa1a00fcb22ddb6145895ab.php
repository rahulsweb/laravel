<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title>Home | E-Shopper</title>
<link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/prettyPhoto.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/price-range.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/main.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/parsley.css')); ?>" rel="stylesheet">

<!--[if lt IE 9]>
<script src="<?php echo e(asset('frontend/js/html5shiv.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/respond.min.js')); ?>"></script>
<![endif]-->       
<link rel="shortcut icon" href="<?php echo e(asset('frontend/images/ico/favicon.ico')); ?>">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-144-precomposed.png')); ?>">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-114-precomposed.png')); ?>">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-72-precomposed.png')); ?>">
<link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-57-precomposed.png')); ?>">  <link rel="stylesheet" href="<?php echo e(asset('datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">

<!-- Font Awesome -->
<!-- Ionicons -->
<link rel="stylesheet" href="<?php echo e(asset('/Ionicons/css/ionicons.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset('dist/css/AdminLTE.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/skin-blue.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/about-us.css')); ?>">

  <style>
          #wishlist
          {
            color: #B3AFA8;
            font-family: 'Roboto', sans-serif;
            font-size: 13px;
          
        
             background-color: Transparent;

    border: none;
    cursor:pointer;
 
          }
          #wishlist:hover
          {
            color:orange;
          }
  
          .text-large
          {
            font-size: 2em;
            text-align:center !important;
          }
          .pagination
          {
            float:right;
          }


          #search
          {
            background: #F0F0E9;
    border: medium none;
    color: #B2B2B2;
    font-family: 'roboto';
    font-size: 12px;
    font-weight: 300;
    height: 35px;
    outline: medium none;
    padding-left: 10px;
    width: 155px;
    background-image: url(../images/home/searchicon.png);
    background-repeat: no-repeat;
    background-position: 130px;
          }

       
          
        
          
          /* Background images are set within the HTML using inline CSS, not here */
          
          .girl{
            margin-left:-40px;
            
          }
          .sub ul
          {
            background:none !important;
            margin:0;
            border-bottom:none;
          }
          .add-to-cart
          {
            margin-bottom: 8px; 
          }


              .zoom:hover {

                transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
              }
           

          
          </style>
<!-- Google Font -->
<link rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

