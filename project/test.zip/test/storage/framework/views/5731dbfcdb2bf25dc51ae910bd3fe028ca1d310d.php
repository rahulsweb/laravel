

<div class="category-tab">
        <!--category-tab-->
        <div class="col-sm-12">
            <ul class="nav nav-tabs">
                <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php echo e($key == 0 ? ' active' : ''); ?>"><a href="#<?php echo e($value->name); ?>" class="category_tab" data-toggle="tab"  name="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              
               
            </ul>
        </div>
       
        <div class="tab-content">
                <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
            <div class="tab-pane fade  <?php echo e($key == 0 ? ' active' : ''); ?>  in" id="<?php echo e($value->name); ?>">
                  
         <div class="row col-sm-12" id="sub_categories">
                <div class="col-sm-3">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <img id="image" src="<?php echo e(asset('frontend/images/home/gallery1.jpg')); ?>" alt="" />
                                <h2 id="rate">$56</h2>
                                <p></p>
                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
              
            </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
        </div>

    </div>





  