<?php 


echo htmlspecialchars_decode($template);



