<?php $__env->startSection('content'); ?>
<h1> Rahul Run</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_theme.frontend_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>