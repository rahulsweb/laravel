<!DOCTYPE html>
<html lang="en">

<head>
   <?php echo $__env->make('frontend_theme.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<!--/head-->

<body>
    <?php echo $__env->make('frontend_theme.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--/header-->


    <?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldSection(); ?>



    <?php echo $__env->make('frontend_theme.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- footer -->

   

    <?php echo $__env->make('frontend_theme.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>