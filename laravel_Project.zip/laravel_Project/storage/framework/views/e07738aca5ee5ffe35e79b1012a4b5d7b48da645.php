  
 <?php $__env->startPush('styles'); ?>



<?php $__env->stopPush(); ?>
 <?php $__env->startSection('content'); ?>
<section id="form">
    <!--form-->
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-sm-offset-4">
                <div class="login-form">
                    <!--login form-->
                     
                    <?php if(Session::has('register')): ?>
                    <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('register')); ?></p>
                    <?php endif; ?>
                
                    <h2>Login to your account</h2>
                  
                </div>
                <!--/login form-->
        
          
         
                <div class="signup-form">
               
                    
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('frontend/login')); ?>">
                        <a href="<?php echo e(url('auth/google')); ?>" class="btn btn-lg btn-primary btn-block">
                            <strong>Login With Google</strong></a>
                            <?php echo e(csrf_field()); ?>








                                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                   
                                    <input class="form-control" name="email" placeholder="Email-Id" type="text" id="email" value="<?php echo e(isset($adminuser->email) ? $adminuser->email : ''); ?>" >
                                    <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

                                </div>
                                <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                   
                                    <input class="form-control" name="password" type="text" id="password" placeholder="Password" value="<?php echo e(isset($adminuser->password) ? $adminuser->password : ''); ?>" >
                                    <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

                                </div>
                              


                                    <div class="form-group">
                                            <input class="btn-lg btn-success text-muted" style="background-color:orange;" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
                                       
                                             <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a>
                                        </div>
                                       

                    </form>
                </div>
            </div>
                <!--/sign up form-->
            </div>
        </div>
    </div>
</section>
<!--/form-->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?> 


<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend_theme.frontend_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>