<!DOCTYPE html>
<html lang="en">

<head>
   @include('frontend_theme.styles')
   @stack('styles')
</head>
<!--/head-->

<body>
    @include('frontend_theme.header')
    <!--/header-->

{{-- add section  --}}
    @section('content')
    @show



    @include('frontend_theme.footer')
    <!-- footer -->

   

    @include('frontend_theme.scripts')
    @stack('scripts')
</body>

</html>