@extends('frontend_theme.frontend_layout')   
    
  @section('content')  
    @include('frontend_theme.slider')
   


    @include('frontend_theme.section2')
    @endsection 