@extends('frontend_theme.frontend_layout')
@section('content')
<h1> Rahul Run</h1>
@endsection