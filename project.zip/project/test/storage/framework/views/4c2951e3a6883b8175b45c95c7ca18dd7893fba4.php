  
    <script src="<?php echo e(asset('frontend/js/jquery.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/price-range.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.scrollUp.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/parsley.js')); ?>"></script> 

    <!-- jQuery 3 -->

<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- AdminLTE App -->

<script src="<?php echo e(asset('datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<link href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet"></link>
<script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
<script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>

<script>
        $(document).ready(function(){
         
          $('.category_tab').click(function(){
       
           var  id=$(this).attr('name');
           $.ajax({
            type:'POST',
            url:"<?php echo e(route('sub_category.product')); ?>",
            data:{'_token':"<?php echo e(csrf_token()); ?>",'id':id},
            success:function(data) {
               
            
               var str="";
                $.each( data, function( key, value ) {
                
                    
       
                    str+=' <div class="col-sm-3">';
                            str+=' <div class="product-image-wrapper">';
                                    str+='<div class="single-products">'; 
                                            str+='<div class="productinfo text-center">';
                                                    str+=' <img id="image" src="'+value.image+'" alt="" />';
                                                    str+='<h2 id="rate">'+value.name+'</h2>';
                                                    str+='<h2 id="rate">'+value.rate+'</h2>';
                                                    str+=' <a href="<?php echo e(url('cart/detail'
                                                    
                                                    )); ?>" class="btn btn-default add-to-cart">';
                                                        
                                                        str+=  '<i class="fa fa-shopping-cart"></i>Add to cart</a>';
                                                    str+=' </div>';
                                                    str+=' </div>';  
                                                    str+=' </div>';
                                                    str+=' </div>';
                                               

  
               
            });
            $('#sub_categories').html(str);
        }
         });
        
        });
        
    });     
        
        </script>