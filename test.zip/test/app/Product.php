<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'products';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['name','rate'];

    
    public function categories()
    {
        return $this->hasMany(ProductCategory::class);
    }
    public function product_category()
    {
        
        return $this->hasOne(ProductCategory::class);
       
    }
    public function product_image()
    {
        return $this->hasMany(ProductImage::class);
      
       
    }
    public function product_attribute()
    {
        return $this->hasMany(ProductAttribute::class);
       
    }
    
}




