<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="name" class="control-label"><?php echo e('Full Name'); ?></label>
    <input class="form-control" name="fullname"  placeholder="Enter The Full Name" type="text" id="name" value="<?php echo e(isset($address->name) ? $address->name : ''); ?>" >
    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('country') ? 'has-error' : ''); ?>">
    <label for="country" class="control-label"><?php echo e('Country'); ?></label>
    <input class="form-control" country="country" type="text" id="country"  name="country" value="<?php echo e(isset($address->country) ? $address->country : ''); ?>" >
    <?php echo $errors->first('country', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('state') ? 'has-error' : ''); ?>">
    <label for="state" class="control-label"><?php echo e('State'); ?></label>
    <input class="form-control" state="state" type="text" id="state"  name="state" value="<?php echo e(isset($address->state) ? $address->state : ''); ?>" >
    <?php echo $errors->first('state', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('pincode') ? 'has-error' : ''); ?>">
    <label for="pincode" class="control-label"><?php echo e('Pincode'); ?></label>
    <input class="form-control" pincode="pincode" type="text" id="pincode"  name="pincode" value="<?php echo e(isset($address->pincode) ? $address->pincode : ''); ?>" >
    <?php echo $errors->first('pincode', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
