<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="name" class="control-label"><?php echo e('name'); ?></label>
    <input class="form-control" name="name" type="text" id="name" value="<?php echo e(isset($role->name) ? $role->name : ''); ?>" >
    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('permission') ? 'has-error' : ''); ?>">
    <label for="permission" class="control-label"><?php echo e('Permissions'); ?></label>



    <?php echo $errors->first('permission', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group">
  <ul class="list-group">
  <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="list-group-item">
    <label>
          <input type="checkbox" name="permissions[]"  class="flat-red " value="<?php echo e($permission->id); ?>">  <?php echo e($permission->name); ?>

    </label>
  </li>
 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
  </div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
