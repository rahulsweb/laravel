<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <label for="title" class="control-label"><?php echo e('Title'); ?></label>
    <input class="form-control" name="title" type="text" id="title" value="<?php echo e(isset($post->title) ? $post->title : ''); ?>" required>
    <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
    <label for="content" class="control-label"><?php echo e('Content'); ?></label>
    <textarea class="form-control" rows="5" name="content" type="textarea" id="content" ><?php echo e(isset($post->content) ? $post->content : ''); ?></textarea>
    <?php echo $errors->first('content', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('category') ? 'has-error' : ''); ?>">
    <label for="category" class="control-label"><?php echo e('Category'); ?></label>
    <select name="category" class="form-control" id="category" >
    <?php $__currentLoopData = json_decode('{"technology":"Technology","tips":"Tips","health":"Health"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($optionKey); ?>" <?php echo e((isset($post->category) && $post->category == $optionKey) ? 'selected' : ''); ?>><?php echo e($optionValue); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
    <?php echo $errors->first('category', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
    <label for="user_id" class="control-label"><?php echo e('User Id'); ?></label>
    <input class="form-control" name="user_id" type="number" id="user_id" value="<?php echo e(isset($post->user_id) ? $post->user_id : ''); ?>" >
    <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
