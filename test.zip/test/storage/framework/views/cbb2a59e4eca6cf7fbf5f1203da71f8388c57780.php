 
<?php $__env->startPush('styles'); ?>

<style>
  .header
   {
       font-size: 20px;
       text-align: center !important;
   }
</style>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section id="form">
   <!--form-->
   <div class="container">
       <div class="row">
           <div class="col-sm-4 col-sm-offset-4">
               <div class="login-form">
                   <!--login form-->
<?php echo e(var_dump($errors->messageBagName->first('first_name'))); ?>

                   <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
    <h2 class="text-success header">Register Your ACCOUNT</h2>
                    </div>
                  
                   <form class="form-horizontal" method="POST" action="<?php echo e(url('frontend/register')); ?>">
                    <?php echo e(csrf_field()); ?>








                    <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                            
                            <input class="form-control" name="first_name"  placeholder="First Name" type="text" id="first_name" value="<?php echo e(isset($adminuser->first_name) ? $adminuser->first_name : ''); ?>" >
                            <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
              
                            <input class="form-control" name="last_name" type="text" placeholder="Last Name" id="last_name" value="<?php echo e(isset($adminuser->last_name) ? $adminuser->last_name : ''); ?>" >
                            <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

                        </div>
                        
                        <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                           
                            <input class="form-control" name="email" placeholder="Email-Id" type="text" id="email" value="<?php echo e(isset($adminuser->email) ? $adminuser->email : ''); ?>" >
                            <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                           
                            <input class="form-control" name="password" type="text" id="password" placeholder="Password" value="<?php echo e(isset($adminuser->password) ? $adminuser->password : ''); ?>" >
                            <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="form-group <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
                               
                                <input class="form-control" name="confirm_password" placeholder="Confirm Password" type="text" id="confirm_password" value="<?php echo e(isset($adminuser->confirm_password) ? $adminuser->confirm_password : ''); ?>" >
                                <?php echo $errors->first('confirm_password', '<p class="help-block">:message</p>'); ?>

                            </div>


                            <div class="form-group">
                                    <input class="btn-lg btn-success text-muted" style="background-color:orange;" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
                                </div>
                               

            </form>
                 
               </div>
               <!--/login form-->
           </div>
        
          
       </div>
   </div>
</section>
<!--/form-->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?> 


<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend_theme.frontend_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>