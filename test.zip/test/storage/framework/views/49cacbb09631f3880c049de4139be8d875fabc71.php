
  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Anything you want
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy;   2019 <a href="#">Company</a>.</strong><span class="text-warning"> Rahulsonawanen@gmail.com </span>All rights reserved.
  </footer>