

<div class="form-group <?php echo e($errors->has('fullname') ? 'has-error' : ''); ?>">
        <label for="fullname" class="control-label"><?php echo e('Full Name'); ?></label>
        <input class="form-control" placeholder="Enter The Full Name" fullname="fullname" type="text" id="fullname"  name="fullname" value="<?php echo e(isset($address->fullname) ? $address->fullname : ''); ?>" >
        <?php echo $errors->first('fullname', '<p class="help-block">:message</p>'); ?>

    </div>
    <div class="form-group <?php echo e($errors->has('address1') ? 'has-error' : ''); ?>">
            <label for="address1" class="control-label"><?php echo e('Address'); ?></label>
            <input class="form-control" placeholder="Enter The Address" address1="address1" type="text" id="address1"  name="address1" value="<?php echo e(isset($address->address1) ? $address->address1 : ''); ?>" >
            <?php echo $errors->first('address1', '<p class="help-block">:message</p>'); ?>

        </div>
    <div class="form-group <?php echo e($errors->has('address2') ? 'has-error' : ''); ?>">
            <label for="address2" class="control-label"><?php echo e('Alternate Address'); ?></label>
            <input class="form-control" placeholder="Enter The Another Address" address2="address2" type="text" id="address2"  name="address2" value="<?php echo e(isset($address->address2) ? $address->address2 : ''); ?>" >
            <?php echo $errors->first('address2', '<p class="help-block">:message</p>'); ?>

        </div>
<div class="form-group <?php echo e($errors->has('country') ? 'has-error' : ''); ?>">
    <label for="country" class="control-label"><?php echo e('Country'); ?></label>
    <input class="form-control" placeholder="Enter The Country" country="country" type="text" id="country"  name="country" value="<?php echo e(isset($address->country) ? $address->country : ''); ?>" >
    <?php echo $errors->first('country', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('state') ? 'has-error' : ''); ?>">
    <label for="state" class="control-label"><?php echo e('State'); ?></label>
    <input class="form-control" placeholder="Enter The State" state="state" type="text" id="state"  name="state" value="<?php echo e(isset($address->state) ? $address->state : ''); ?>" >
    <?php echo $errors->first('state', '<p class="help-block">:message</p>'); ?>

</div>

    <div class="form-group <?php echo e($errors->has('pincode') ? 'has-error' : ''); ?>">
            <label for="pincode" class="control-label"><?php echo e('Pincode'); ?></label>
            <input class="form-control" placeholder="Enter The Pincode" pincode="pincode" type="text" id="pincode"  name="pincode" value="<?php echo e(isset($address->pincode) ? $address->pincode : ''); ?>" >
            <?php echo $errors->first('pincode', '<p class="help-block">:message</p>'); ?>

        </div>
<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
