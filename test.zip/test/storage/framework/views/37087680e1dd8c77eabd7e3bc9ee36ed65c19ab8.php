

<?php $__env->startSection('content'); ?>

<?php $__env->startPush('scripts'); ?> 

<!-- jQuery 3 -->

<script>
  $(function () {
    $('#example2').DataTable();
   
  });
</script>

<?php $__env->stopPush(); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Page Header
      <small>Optional description</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
      <li class="active">Here</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content container-fluid">

        <!-- /.content-wrapper -->

        <div class="container">
            <div class="row">
       
    
                <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Product <?php echo e($product->id); ?></div>
                    <div class="card-body">

                        <a href="<?php echo e(url('/admin/product')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/admin/product/' . $product->id . '/edit')); ?>" title="Edit Product"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                        <form method="POST" action="<?php echo e(url('admin/product' . '/' . $product->id)); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Product" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                        </form>
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table id="example2" class="table table-bordered table-hover">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td><?php echo e($product->id); ?></td>
                                    </tr>
                                    <tr><th> Name </th><td> <?php echo e($product->name); ?> </td></tr>
                                    <tr><th> Rate </th><td> <?php echo e($product->rate); ?> </td></tr>
                                    <tr><th> image </th>
                                        <?php $__currentLoopData = $product->product_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td> <img src= " <?php echo e(asset($image->name)); ?>" width=50 heigth=50 ></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                      
                                    </tr>
                                    <tr><th> Category Name </th><td> <?php echo e($product->categories->category->name); ?> </td></tr>
                                    <tr><th> Quantity </th><td> <?php echo e($product->product_attribute->quantity); ?> </td></tr>
                                    <tr><th> Color </th><td> <?php echo e($product->product_attribute->color); ?> </td></tr>
                                </tbody>
                            </table>
                        </div>
    
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /.content -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>