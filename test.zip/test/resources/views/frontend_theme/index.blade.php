@extends('frontend_theme.frontend_layout')   
    
  @section('content')  
    @include('frontend_theme.frontend_index.slider')
   


    @include('frontend_theme.frontend_index.section2')
    @endsection 