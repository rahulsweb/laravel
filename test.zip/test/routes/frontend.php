<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'frontend\FrontendController@index');

    Route::group(['middleware' => ['web']], function () {
        //routes here

      
        
        Route::get('login', function () {
            return view('frontend.login.login',['formMode' => 'create']);
        });
        Route::get('email', function () {
            return view('frontend.login.email');
        });
        Route::get('register','frontend\RegisterController@create')->name('frontend.register.create');

        Route::post('/register', 'frontend\RegisterController@store')->name('frontend.register.store');
        Route::post('/login', 'frontend\LoginController@login')->name('frontend.login');
        Route::post('/logout', 'frontend\LoginController@logout')->name('frontend.logout');
    Route::resource('address', 'frontend\\AddressController');
    });
    Route::get('categories/subcategory/{id}', 'frontend\FrontendController@subcategory')->name('frontend.subcategory');


   
    Route::get('auth/google','Auth\LoginController@redirectToGoogle');
    Route::get('google/callback','Auth\LoginController@handleGoogleCallback');