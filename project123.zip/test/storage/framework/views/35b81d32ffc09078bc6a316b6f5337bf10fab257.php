<div class="col-sm-3">
<div class="left-sidebar">
        <h2>Category</h2>
        <div class="panel-group category-products" id="accordian">
            <!--category-productsr-->
            <?php if(isset($categories)): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
           <?php if(!$category->parent_id): ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordian" href="#<?php echo e($category->name); ?>">
                            <span class="badge pull-right"><i class="fa fa-plus"></i></span>    <?php echo e($category->name); ?>

                        </a>
                    </h4>
                </div>

              
                <div id="<?php echo e($category->name); ?>" class="panel-collapse collapse">
                     
                    
               
                  <div class="panel-body">


                          <ul>
                                <?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($child->products)): ?>
                                
                            <li ><a href="<?php echo e(url('categories/subcategory',$child->id)); ?>"> <strong class="text-warning"> <?php echo e($child->name); ?></strong>  </a></li>
                                <?php endif; ?>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </ul>
                    </div>
                  
               
                </div>
            </div>
            <?php endif; ?>
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          <?php endif; ?>
        </div>
        <!--/category-products-->

        <div class="brands_products">
            <!--brands_products-->
            <h2>Brands</h2>
            <div class="brands-name">
                <ul class="nav nav-pills nav-stacked">
                    <?php if(isset($sub_category )): ?>
                    <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                            <a href="#"> <span class="pull-right">(<?php echo e($value->count); ?>)</span><?php echo e($value->name); ?></a>
                        </li> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                  
                </ul>
            </div>
        </div>
        <!--/brands_products-->

    
        <!--/shipping-->

    </div>
</div>