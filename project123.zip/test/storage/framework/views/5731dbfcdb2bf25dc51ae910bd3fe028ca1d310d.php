

<div class="category-tab">
        <!--category-tab-->
        <div class="col-sm-12" >
            <ul class="nav nav-tabs">
                <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php echo e($key == 0 ? ' active' : ''); ?>"><a href="#<?php echo e($value->name); ?>" class="category_tab" data-toggle="tab"  name="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              
               
            </ul>
        </div>
       
        <div class="tab-content">
                <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
            <div class="tab-pane fade  <?php echo e($key == 0 ? ' active' : ''); ?>  in" id="<?php echo e($value->name); ?>">
                
         <div class="row col-sm-12" id="sub_categories">
           <div id="p">    
            <?php $__currentLoopData = $sub_category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3">
                <div class="product-image-wrapper">
                    <div class="single-products">
                        <div class="productinfo text-center">
                    
                            <img id="image" src="<?php echo e(asset( $products->product_image[0]->name)); ?>" alt=""  class="img-fluid"  alt=""   height="150" />
                            <strong><?php echo e($products->name); ?></strong>
                            <h2 id="rate"><?php echo e($products->rate); ?></h2>
                            <p></p>
                            <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                       
                        
                        
                        </div>

                    </div>
                </div>
                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 
            </div>
              
            </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
        </div>

    </div>





  